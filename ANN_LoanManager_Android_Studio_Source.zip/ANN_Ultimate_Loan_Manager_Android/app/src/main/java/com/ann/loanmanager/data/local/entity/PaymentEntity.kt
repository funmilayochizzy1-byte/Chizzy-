package com.ann.loanmanager.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "payments",
    indices = [
        Index(value = ["receiptNumber"], unique = true),
        Index(value = ["loanId"]),
        Index(value = ["clientId"]),
        Index(value = ["idempotencyKey"], unique = true),
        Index(value = ["timestamp"])
    ]
)
data class PaymentEntity(
    @PrimaryKey
    val id: String,
    val receiptNumber: String,
    val loanId: String,
    val clientId: String,
    val clientName: String,
    val clientPhone: String,
    val groupName: String,
    val amount: Double,
    val method: String, // CASH or TRANSFER
    val bankName: String? = null, // OPay, PalmPay, Moniepoint, FirstBank, GTBank
    val bankReference: String? = null,
    val notes: String? = null,
    val staffId: String,
    val staffName: String,
    val timestamp: Long = System.currentTimeMillis(),
    val previousBalance: Double,
    val newBalance: Double,
    val idempotencyKey: String, // Prevents duplicate double-tap submissions
    val isReversed: Boolean = false,
    val reversalReason: String? = null,
    val reversedAt: Long? = null,
    val reversedByStaffName: String? = null
)
