package com.ann.loanmanager.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Index

@Entity(
    tableName = "clients",
    indices = [
        Index(value = ["clientNumber"], unique = true),
        Index(value = ["phone"]),
        Index(value = ["groupName"])
    ]
)
data class ClientEntity(
    @PrimaryKey
    val id: String,
    val clientNumber: String,
    val fullName: String,
    val phone: String,
    val altPhone: String? = null,
    val ninBvn: String? = null,
    val residentialAddress: String,
    val businessAddress: String,
    val businessType: String,
    val groupName: String,
    val photoUri: String? = null,
    
    // Guarantor KYC Information
    val guarantorFullName: String,
    val guarantorPhone: String,
    val guarantorAddress: String,
    val guarantorRelationship: String,
    val guarantorOccupation: String,
    val guarantorIdType: String,
    val guarantorIdNumber: String,
    val guarantorPhotoUri: String? = null,

    val status: String = "ACTIVE", // ACTIVE, INACTIVE, BLACKLISTED
    val registrationDate: String,
    val totalLoansCount: Int = 0,
    val activeLoansCount: Int = 0,
    val totalBorrowed: Double = 0.0,
    val totalRepaid: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
