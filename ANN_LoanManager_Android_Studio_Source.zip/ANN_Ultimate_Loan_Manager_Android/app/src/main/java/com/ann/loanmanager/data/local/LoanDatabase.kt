package com.ann.loanmanager.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.ann.loanmanager.data.local.dao.ClientDao
import com.ann.loanmanager.data.local.dao.LoanDao
import com.ann.loanmanager.data.local.dao.PaymentDao
import com.ann.loanmanager.data.local.entity.ClientEntity
import com.ann.loanmanager.data.local.entity.LoanEntity
import com.ann.loanmanager.data.local.entity.PaymentEntity
import com.ann.loanmanager.data.local.entity.SyncLogEntity
import net.sqlcipher.database.SQLiteDatabase
import net.sqlcipher.database.SupportFactory

@Database(
    entities = [
        ClientEntity::class,
        LoanEntity::class,
        PaymentEntity::class,
        SyncLogEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class LoanDatabase : RoomDatabase() {
    abstract fun clientDao(): ClientDao
    abstract fun loanDao(): LoanDao
    abstract fun paymentDao(): PaymentDao

    companion object {
        @Volatile
        private var INSTANCE: LoanDatabase? = null

        fun getInstance(context: Context, passphrase: ByteArray? = null): LoanDatabase {
            return INSTANCE ?: synchronized(this) {
                val builder = Room.databaseBuilder(
                    context.applicationContext,
                    LoanDatabase::class.java,
                    "ann_loan_manager.db"
                )

                // Optional hardware-accelerated SQLCipher AES-256 database encryption
                if (passphrase != null) {
                    val factory = SupportFactory(passphrase)
                    builder.openHelperFactory(factory)
                }

                val instance = builder
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
