package com.ann.loanmanager.data.local.dao

import androidx.room.*
import com.ann.loanmanager.data.local.entity.PaymentEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PaymentDao {
    @Query("SELECT * FROM payments WHERE isReversed = 0 ORDER BY timestamp DESC")
    fun getAllActivePayments(): Flow<List<PaymentEntity>>

    @Query("SELECT * FROM payments WHERE loanId = :loanId ORDER BY timestamp DESC")
    fun getPaymentsForLoan(loanId: String): Flow<List<PaymentEntity>>

    @Query("SELECT * FROM payments WHERE idempotencyKey = :key LIMIT 1")
    suspend fun findByIdempotencyKey(key: String): PaymentEntity?

    @Query("""
        SELECT * FROM payments 
        WHERE loanId = :loanId AND amount = :amount AND isReversed = 0 AND (timestamp >= :minTimestamp)
        LIMIT 1
    """)
    suspend fun findRecentDuplicate(loanId: String, amount: Double, minTimestamp: Long): PaymentEntity?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun recordPayment(payment: PaymentEntity)

    @Update
    suspend fun updatePayment(payment: PaymentEntity)

    @Query("SELECT SUM(amount) FROM payments WHERE isReversed = 0 AND timestamp >= :startOfDay AND timestamp <= :endOfDay")
    suspend fun getTodayCollectionTotal(startOfDay: Long, endOfDay: Long): Double?
}
