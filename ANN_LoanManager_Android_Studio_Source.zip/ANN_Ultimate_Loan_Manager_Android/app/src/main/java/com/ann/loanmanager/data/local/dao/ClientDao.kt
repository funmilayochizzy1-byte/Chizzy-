package com.ann.loanmanager.data.local.dao

import androidx.room.*
import com.ann.loanmanager.data.local.entity.ClientEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ClientDao {
    @Query("SELECT * FROM clients ORDER BY createdAt DESC")
    fun getAllClients(): Flow<List<ClientEntity>>

    @Query("SELECT * FROM clients WHERE id = :clientId LIMIT 1")
    suspend fun getClientById(clientId: String): ClientEntity?

    @Query("""
        SELECT * FROM clients 
        WHERE fullName LIKE '%' || :query || '%' 
           OR phone LIKE '%' || :query || '%' 
           OR clientNumber LIKE '%' || :query || '%'
           OR ninBvn LIKE '%' || :query || '%'
        ORDER BY fullName ASC
    """)
    fun searchClients(query: String): Flow<List<ClientEntity>>

    @Query("SELECT COUNT(*) FROM clients")
    suspend fun getClientsCount(): Int

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertClient(client: ClientEntity)

    @Update
    suspend fun updateClient(client: ClientEntity)

    @Query("UPDATE clients SET totalRepaid = totalRepaid + :amount, updatedAt = :timestamp WHERE id = :clientId")
    suspend fun incrementRepaidAmount(clientId: String, amount: Double, timestamp: Long)
}
