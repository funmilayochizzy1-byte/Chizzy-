package com.ann.loanmanager.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ann.loanmanager.data.local.entity.PaymentEntity
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DailyCollectionScreen(
    payments: List<PaymentEntity>,
    onRecordNewPayment: () -> Unit
) {
    val currencyFormat = remember { NumberFormat.getCurrencyInstance(Locale("en", "NG")) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Daily Collections (Cash & Transfer)") }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onRecordNewPayment) {
                Text("+ Record")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(payments, key = { it.id }) { payment ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(payment.clientName, style = MaterialTheme.typography.titleMedium)
                            Text(
                                "₦" + String.format("%,.0f", payment.amount),
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Receipt: ${payment.receiptNumber}", style = MaterialTheme.typography.bodySmall)
                        Text(
                            "Method: ${payment.method} ${payment.bankName?.let { "($it)" } ?: ""}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            "Balance Remaining: ₦" + String.format("%,.0f", payment.newBalance),
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
            }
        }
    }
}
