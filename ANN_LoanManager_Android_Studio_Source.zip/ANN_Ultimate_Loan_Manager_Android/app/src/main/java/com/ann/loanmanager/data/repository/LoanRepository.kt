package com.ann.loanmanager.data.repository

import androidx.room.withTransaction
import com.ann.loanmanager.data.local.LoanDatabase
import com.ann.loanmanager.data.local.entity.LoanEntity
import com.ann.loanmanager.data.local.entity.PaymentEntity
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class LoanRepository(private val db: LoanDatabase) {
    val activePayments: Flow<List<PaymentEntity>> = db.paymentDao().getAllActivePayments()

    /**
     * Records a collection payment with strict duplicate prevention and atomic loan balance update.
     * Prevents accidental double clicks or duplicate submissions.
     */
    suspend fun recordDailyCollection(
        loanId: String,
        amount: Double,
        method: String,
        bankName: String?,
        bankReference: String?,
        staffId: String,
        staffName: String,
        idempotencyKey: String
    ): Result<PaymentEntity> {
        val now = System.currentTimeMillis()

        // 1. Check idempotency token
        val existing = db.paymentDao().findByIdempotencyKey(idempotencyKey)
        if (existing != null) {
            return Result.failure(IllegalStateException("Duplicate payment prevented: receipt ${existing.receiptNumber} already exists."))
        }

        // 2. Check 5-minute duplicate guard
        val recentDuplicate = db.paymentDao().findRecentDuplicate(loanId, amount, now - 300_000)
        if (recentDuplicate != null) {
            return Result.failure(IllegalStateException("Warning: An identical payment of ₦$amount was recorded ${(now - recentDuplicate.timestamp)/1000}s ago."))
        }

        // 3. Atomic transaction execution
        return db.withTransaction {
            val loan = db.loanDao().getLoanById(loanId)
                ?: return@withTransaction Result.failure(IllegalArgumentException("Loan not found."))

            val previousBalance = loan.remainingBalance
            val newTotalPaid = loan.totalPaid + amount
            val newBalance = maxOf(0.0, loan.totalPayable - newTotalPaid)

            val receiptNumber = "ANN-RCP-${System.currentTimeMillis()}"

            val payment = PaymentEntity(
                id = UUID.randomUUID().toString(),
                receiptNumber = receiptNumber,
                loanId = loanId,
                clientId = loan.clientId,
                clientName = loan.clientName,
                clientPhone = loan.clientPhone,
                groupName = loan.groupName,
                amount = amount,
                method = method,
                bankName = bankName,
                bankReference = bankReference,
                staffId = staffId,
                staffName = staffName,
                timestamp = now,
                previousBalance = previousBalance,
                newBalance = newBalance,
                idempotencyKey = idempotencyKey
            )

            db.paymentDao().recordPayment(payment)
            db.loanDao().updateLoanBalances(
                loanId = loanId,
                totalPaid = newTotalPaid,
                remainingBalance = newBalance,
                status = if (newBalance <= 0.0) "COMPLETED" else loan.status,
                timestamp = now
            )
            db.clientDao().incrementRepaidAmount(loan.clientId, amount, now)

            Result.success(payment)
        }
    }
}
