package com.ann.loanmanager.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "sync_queue",
    indices = [
        Index(value = ["status"]),
        Index(value = ["timestamp"])
    ]
)
data class SyncLogEntity(
    @PrimaryKey
    val id: String,
    val entityType: String, // CLIENT, LOAN, PAYMENT, EXPENSE
    val entityId: String,
    val action: String, // INSERT, UPDATE, DELETE
    val payloadJson: String,
    val timestamp: Long = System.currentTimeMillis(),
    val deviceId: String,
    val status: String = "PENDING", // PENDING, SYNCED, FAILED
    val errorMessage: String? = null
)
