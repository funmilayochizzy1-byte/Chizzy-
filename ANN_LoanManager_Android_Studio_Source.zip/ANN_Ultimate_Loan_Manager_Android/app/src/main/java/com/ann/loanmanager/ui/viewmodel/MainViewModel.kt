package com.ann.loanmanager.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ann.loanmanager.data.local.entity.ClientEntity
import com.ann.loanmanager.data.local.entity.PaymentEntity
import com.ann.loanmanager.data.repository.LoanRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class DashboardUiState(
    val totalPortfolio: Double = 0.0,
    val activeLoansCount: Int = 0,
    val todayCollectionTotal: Double = 0.0,
    val pendingSyncCount: Int = 0,
    val recentPayments: List<PaymentEntity> = emptyList(),
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)

class MainViewModel(private val repository: LoanRepository) : ViewModel() {
    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()

    init {
        observeCollections()
    }

    private fun observeCollections() {
        viewModelScope.launch {
            repository.activePayments.collect { payments ->
                _uiState.update { it.copy(recentPayments = payments.take(20)) }
            }
        }
    }

    fun submitPayment(
        loanId: String,
        amount: Double,
        method: String,
        bankName: String?,
        bankReference: String?,
        staffId: String,
        staffName: String
    ) {
        viewModelScope.launch {
            val idempotencyToken = "PAY-$loanId-$amount-${System.currentTimeMillis()}"
            val result = repository.recordDailyCollection(
                loanId = loanId,
                amount = amount,
                method = method,
                bankName = bankName,
                bankReference = bankReference,
                staffId = staffId,
                staffName = staffName,
                idempotencyKey = idempotencyToken
            )
            result.onFailure { error ->
                _uiState.update { it.copy(errorMessage = error.message) }
            }
        }
    }
}
