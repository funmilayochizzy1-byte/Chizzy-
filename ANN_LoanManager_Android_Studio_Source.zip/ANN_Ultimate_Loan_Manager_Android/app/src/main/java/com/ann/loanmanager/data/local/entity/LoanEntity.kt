package com.ann.loanmanager.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "loans",
    foreignKeys = [
        ForeignKey(
            entity = ClientEntity::class,
            parentColumns = ["id"],
            childColumns = ["clientId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [
        Index(value = ["loanNumber"], unique = true),
        Index(value = ["clientId"]),
        Index(value = ["status"])
    ]
)
data class LoanEntity(
    @PrimaryKey
    val id: String,
    val loanNumber: String,
    val clientId: String,
    val clientName: String,
    val clientPhone: String,
    val groupName: String,

    // Financial Terms
    val principal: Double, // e.g. 100,000.0
    val interestRatePercent: Double = 20.0,
    val totalInterest: Double, // e.g. 20,000.0
    val totalPayable: Double, // e.g. 120,000.0
    val durationDays: Int = 24, // 24 working days
    val repaymentFrequency: String = "DAILY_WORKING",
    val installmentAmount: Double = 5000.0, // ₦5,000 per working day

    // Dates
    val startDate: String,
    val expectedEndDate: String,
    val disbursedAt: Long? = null,
    val completedAt: Long? = null,

    // Status and Balances
    val status: String = "ACTIVE", // PENDING_APPROVAL, ACTIVE, COMPLETED, DEFAULTED
    val totalPaid: Double = 0.0,
    val remainingBalance: Double,
    val arrearsAmount: Double = 0.0,
    val daysOverdue: Int = 0,

    // Repayment schedule stored as serialized JSON
    val scheduleJson: String,

    val approvedByStaffId: String? = null,
    val disbursedByStaffId: String? = null,
    val disbursementMethod: String = "BANK_TRANSFER", // CASH or BANK_TRANSFER
    val notes: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
