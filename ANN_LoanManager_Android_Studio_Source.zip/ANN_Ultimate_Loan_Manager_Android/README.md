# ANN Ultimate Loan Manager - Native Android Project

Built with Kotlin 2.0, Jetpack Compose, Room Database with SQLCipher, and StateFlow.

## Setup Instructions
1. Open Android Studio Ladybug or Jellyfish.
2. Select "Open an Existing Project" and choose this directory.
3. Sync Gradle and build APK via Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Supports offline-first Room local persistence and multi-phone synchronization.
